package com.example.demo.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Employee;
import com.example.demo.service.EmpService;

@RestController
@RequestMapping("/employees")
public class EmpController {

    private final EmpService empService;

    // Constructor injection (Sửa lỗi @Autowired bị cảnh báo)
    public EmpController(EmpService empService) {
        this.empService = empService;
    }

    @PostMapping("/add")
    public void addEmployee(@RequestBody Employee employee) {
        empService.addEmployee(employee);
    }

    @GetMapping("/findall")
    public List<Employee> getAllEmployees() {
        return empService.findAllEmployees();
    }

    @GetMapping("/findbyid/{id}")
    public Employee getEmployeeById(@PathVariable long id) {
        return empService.findEmployeeById(id);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteById(@PathVariable long id) {
        empService.deleteEmployeeById(id);
    }

    @DeleteMapping("/delete/all")
    public void deleteAll() {
        empService.deleteAllData();
    }
}
