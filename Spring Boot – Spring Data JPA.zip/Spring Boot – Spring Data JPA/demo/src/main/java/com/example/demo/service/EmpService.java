package com.example.demo.service;

import com.example.demo.model.Employee;
import java.util.List;

public interface EmpService {
    List<Employee> findAllEmployees(); // Sửa lại tên cho đúng quy ước
    Employee findEmployeeById(long id); // Sửa tên hàm cho dễ hiểu
    void addEmployee(Employee employee); // Thêm tham số đầu vào
    void deleteEmployeeById(long id); // Xóa theo ID
    void deleteAllData();
}
